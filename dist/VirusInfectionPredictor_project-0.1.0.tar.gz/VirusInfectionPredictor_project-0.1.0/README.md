# Virus Infection Predictor (VIP)

**Goal**: Predict hosts for virus of interest from sequence data


**Input**: Sequences for viruses and hosts of interest


**Output**: A network of possible interactions between virus and hosts of interest


