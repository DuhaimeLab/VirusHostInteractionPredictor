from setuptools import setup 

setup(name='VirusInfectionPredictor_project', version = '0.1.0', packages=['vip']) 
