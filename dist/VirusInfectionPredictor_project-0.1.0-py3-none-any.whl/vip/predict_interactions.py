import pandas as pd


def load_pairs(path):
    pairs = pd.read_csv(path)

    # add code to check input is formatted correctly for prediction


def predict_interactions():

    pass



